a = 1
print(a)
