library(reticulate)
py_available(initialize = FALSE)
py_numpy_available(initialize = FALSE)
a <-0 
reticulate::source_python("test1.py")
print(a)
